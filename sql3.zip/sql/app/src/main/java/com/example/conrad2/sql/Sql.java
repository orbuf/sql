package com.example.conrad2.sql;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Sql extends SQLiteOpenHelper {
  public static final String DATABASE_NAME="DATABASE";
    public static final String DATABASE_TABLE="MYNAME";
    public static final String id="_id";
    public static final String NAME="NAME";
    public static final int DATABASE_VERSION=1;
   public static final String DATABASE_CREATE= " CREATE TABLE "+ DATABASE_TABLE+ "(" +id+" INTEGER PRIMARY KEY AUTOINCREMENT, "+NAME+" VARCHAR(255));";
    private static final String DROP_TABLE="DROP TABLE IF EXISTS"+DATABASE_NAME;
    private Context context;



        public Sql(Context context){

          super(context, DATABASE_NAME,null,DATABASE_VERSION);
          this.context=context;
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
           try {
               db.execSQL(DATABASE_CREATE);
           } catch(SQLException e){

            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
                onCreate(db);
            }catch(SQLException e){

            }
        }



}
