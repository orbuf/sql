package com.example.conrad2.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   //Sql helper;
    DataBase db;
   ContentValues contentValues= new ContentValues();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new DataBase(this);
        long id=db.insertData("Test", "type");
       // helper=new Sql(this);
        //SQLiteDatabase myDatabase=helper.getWritableDatabase();
    }

    public void onClicked(View v){
      String data=db.getData();
        Toast.makeText(this, data, Toast.LENGTH_LONG).show();

    }


}
