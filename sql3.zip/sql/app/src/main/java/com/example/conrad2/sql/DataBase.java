package com.example.conrad2.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.ContactsContract;

public class DataBase {
private SQLiteDatabase db;
private Context context;
private final Sql helper;

public DataBase(Context c    ){
context=c;
helper=new Sql(context);


}



    public long insertData(String name, String type){
   SQLiteDatabase db= helper.getWritableDatabase();
   ContentValues contentValues= new ContentValues();
    contentValues.put("NAME",name);
        contentValues.put("TYPE",type);
        long id=db.insert("TABLE_NAME", null, contentValues);
        return id;


    }

    public String getData() {
    SQLiteDatabase db = helper.getWritableDatabase();
    String[] columns={Sql.id, Sql.NAME};
    Cursor cursor= db.query(Sql.DATABASE_TABLE, columns,null,null,null,null,null);

    StringBuffer buffer= new StringBuffer();
    while(cursor.moveToNext()){
        int index= cursor.getInt(0);
        String name=cursor.getString(1);
        buffer.append(index+" "+name+"\n");
    }
     return buffer.toString();
    }
}
